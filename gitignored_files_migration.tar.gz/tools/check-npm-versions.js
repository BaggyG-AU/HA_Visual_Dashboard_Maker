#!/usr/bin/env node

/**
 * NPM Version Checker Script
 *
 * This script checks the latest versions of npm packages used in the project
 * and compares them with the currently installed versions.
 *
 * Usage:
 *   node tools/check-npm-versions.js
 *   node tools/check-npm-versions.js --json (for JSON output)
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

// Read package.json
const packageJsonPath = path.join(__dirname, '..', 'package.json');
const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf8'));

// Packages to check
const packagesToCheck = {
  'Core Dependencies': [
    'react',
    'react-dom',
    'react-grid-layout',
    'monaco-editor',
    '@monaco-editor/react',
    'monaco-yaml',
    'antd',
    'react-colorful',
    'apexcharts',
    'react-apexcharts',
    'electron',
    'home-assistant-js-websocket',
  ],
  'Build Tools': [
    '@electron-forge/cli',
    '@electron-forge/plugin-vite',
    'vite',
    'typescript',
  ],
  'Testing': [
    '@playwright/test',
    'playwright',
    'vitest',
    '@testing-library/react',
  ],
  'State & UI': [
    'zustand',
    'allotment',
    '@material/web',
  ],
  'Utilities': [
    'js-yaml',
    'electron-store',
    'ws',
  ],
};

// Get package info from npm registry
function getNpmPackageInfo(packageName) {
  return new Promise((resolve, reject) => {
    const url = `https://registry.npmjs.org/${packageName}`;

    https.get(url, (res) => {
      let data = '';

      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve({
            name: packageName,
            latest: parsed['dist-tags']?.latest || 'unknown',
            time: parsed.time?.[parsed['dist-tags']?.latest] || 'unknown',
            description: parsed.description || '',
            repository: parsed.repository?.url || '',
            homepage: parsed.homepage || '',
          });
        } catch (e) {
          reject(new Error(`Failed to parse data for ${packageName}: ${e.message}`));
        }
      });
    }).on('error', (err) => {
      reject(new Error(`Failed to fetch ${packageName}: ${err.message}`));
    });
  });
}

// Get current version from package.json
function getCurrentVersion(packageName) {
  return packageJson.dependencies?.[packageName] ||
         packageJson.devDependencies?.[packageName] ||
         'not installed';
}

// Clean version string (remove ^, ~, etc.)
function cleanVersion(version) {
  return version.replace(/^[\^~]/, '');
}

// Compare versions
function compareVersions(current, latest) {
  const currentClean = cleanVersion(current);

  if (current === 'not installed') return 'not-installed';
  if (currentClean === latest) return 'up-to-date';

  const currentParts = currentClean.split('.').map(n => parseInt(n, 10));
  const latestParts = latest.split('.').map(n => parseInt(n, 10));

  for (let i = 0; i < 3; i++) {
    const curr = currentParts[i] || 0;
    const lat = latestParts[i] || 0;

    if (curr < lat) {
      if (i === 0) return 'major-update';
      if (i === 1) return 'minor-update';
      return 'patch-update';
    }
    if (curr > lat) return 'ahead';
  }

  return 'up-to-date';
}

// Format date
function formatDate(dateString) {
  if (dateString === 'unknown') return 'unknown';
  const date = new Date(dateString);
  return date.toISOString().split('T')[0];
}

// Main function
async function checkVersions() {
  const isJsonOutput = process.argv.includes('--json');
  const results = {};

  if (!isJsonOutput) {
    console.log('='.repeat(80));
    console.log('NPM Package Version Check');
    console.log('Project:', packageJson.name, 'v' + packageJson.version);
    console.log('='.repeat(80));
    console.log();
  }

  for (const [category, packages] of Object.entries(packagesToCheck)) {
    if (!isJsonOutput) {
      console.log(`\n${category}:`);
      console.log('-'.repeat(80));
    }

    results[category] = [];

    for (const packageName of packages) {
      try {
        const info = await getNpmPackageInfo(packageName);
        const current = getCurrentVersion(packageName);
        const status = compareVersions(current, info.latest);

        const result = {
          package: packageName,
          current: current,
          latest: info.latest,
          released: formatDate(info.time),
          status: status,
          repository: info.repository,
          homepage: info.homepage,
        };

        results[category].push(result);

        if (!isJsonOutput) {
          const statusSymbol = {
            'up-to-date': '✓',
            'major-update': '⚠ MAJOR',
            'minor-update': '↑ MINOR',
            'patch-update': '↑ PATCH',
            'ahead': '→ AHEAD',
            'not-installed': '✗ NOT INSTALLED',
          }[status];

          console.log(`  ${statusSymbol} ${packageName}`);
          console.log(`     Current: ${current}`);
          console.log(`     Latest:  ${info.latest} (${formatDate(info.time)})`);

          if (status === 'major-update') {
            console.log(`     ⚠️  Major version update available - review breaking changes!`);
          }
        }

      } catch (error) {
        if (!isJsonOutput) {
          console.log(`  ✗ ${packageName}: ${error.message}`);
        }
        results[category].push({
          package: packageName,
          error: error.message,
        });
      }
    }
  }

  if (isJsonOutput) {
    console.log(JSON.stringify(results, null, 2));
  } else {
    console.log();
    console.log('='.repeat(80));
    console.log('Summary:');
    console.log('-'.repeat(80));

    let totalPackages = 0;
    let upToDate = 0;
    let majorUpdates = 0;
    let minorUpdates = 0;
    let patchUpdates = 0;

    for (const category of Object.values(results)) {
      for (const result of category) {
        if (result.status) {
          totalPackages++;
          if (result.status === 'up-to-date') upToDate++;
          if (result.status === 'major-update') majorUpdates++;
          if (result.status === 'minor-update') minorUpdates++;
          if (result.status === 'patch-update') patchUpdates++;
        }
      }
    }

    console.log(`Total packages checked: ${totalPackages}`);
    console.log(`Up to date: ${upToDate}`);
    console.log(`Major updates available: ${majorUpdates}`);
    console.log(`Minor updates available: ${minorUpdates}`);
    console.log(`Patch updates available: ${patchUpdates}`);
    console.log();
    console.log('To update a package: npm install <package>@latest');
    console.log('To update all packages: npm update');
    console.log('To check outdated: npm outdated');
    console.log('='.repeat(80));
  }
}

// Run
checkVersions().catch(console.error);
