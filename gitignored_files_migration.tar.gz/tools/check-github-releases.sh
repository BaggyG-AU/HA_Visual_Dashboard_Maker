#!/bin/bash

# GitHub Release Checker for Home Assistant Custom Cards
#
# This script uses the GitHub API to fetch latest release information
# for custom cards. No authentication required for public repos (60 req/hour limit).
#
# Usage:
#   bash tools/check-github-releases.sh
#   bash tools/check-github-releases.sh --json (for JSON output)

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Repositories to check (owner/repo format)
declare -A REPOS=(
    ["Home Assistant Core"]="home-assistant/core"
    ["Bubble Card"]="Clooos/Bubble-Card"
    ["Mushroom Cards"]="piitaya/lovelace-mushroom"
    ["Mini Graph Card"]="kalkih/mini-graph-card"
    ["Button Card"]="custom-cards/button-card"
    ["ApexCharts Card"]="RomRider/apexcharts-card"
    ["Auto Entities"]="thomasloven/lovelace-auto-entities"
    ["Card Mod"]="thomasloven/lovelace-card-mod"
    ["Vertical Stack in Card"]="ofekashery/vertical-stack-in-card"
    ["Mini Media Player"]="kalkih/mini-media-player"
    ["Multiple Entity Row"]="benct/lovelace-multiple-entity-row"
    ["Fold Entity Row"]="thomasloven/lovelace-fold-entity-row"
    ["Slider Entity Row"]="thomasloven/lovelace-slider-entity-row"
    ["Battery State Card"]="maxwroc/battery-state-card"
    ["WebRTC Camera"]="AlexxIT/WebRTC"
    ["Frigate Card"]="dermotduffy/frigate-hass-card"
    ["Power Flow Card"]="ulic75/power-flow-card"
    ["Decluttering Card"]="custom-cards/decluttering-card"
    ["Swipe Card"]="bramkragten/swipe-card"
)

# Check if jq is installed
if ! command -v jq &> /dev/null; then
    echo -e "${RED}Error: jq is required but not installed.${NC}"
    echo "Install with: sudo apt-get install jq (Ubuntu/Debian) or brew install jq (macOS)"
    exit 1
fi

# Check if curl is installed
if ! command -v curl &> /dev/null; then
    echo -e "${RED}Error: curl is required but not installed.${NC}"
    exit 1
fi

JSON_OUTPUT=false
if [[ "$1" == "--json" ]]; then
    JSON_OUTPUT=true
fi

# Function to fetch latest release info
get_release_info() {
    local repo="$1"
    local url="https://api.github.com/repos/${repo}/releases/latest"

    # Fetch release info
    local response
    response=$(curl -s -H "Accept: application/vnd.github.v3+json" "$url")

    # Check if request was successful
    if echo "$response" | jq -e .message &> /dev/null; then
        local error_msg
        error_msg=$(echo "$response" | jq -r .message)
        echo "ERROR: $error_msg"
        return 1
    fi

    # Extract info
    local tag_name
    local published_at
    local html_url
    local name

    tag_name=$(echo "$response" | jq -r .tag_name)
    published_at=$(echo "$response" | jq -r .published_at | cut -d'T' -f1)
    html_url=$(echo "$response" | jq -r .html_url)
    name=$(echo "$response" | jq -r .name)

    if [[ "$tag_name" == "null" ]]; then
        echo "ERROR: No releases found"
        return 1
    fi

    echo "${tag_name}|${published_at}|${html_url}|${name}"
    return 0
}

# Main execution
if [[ "$JSON_OUTPUT" == false ]]; then
    echo "========================================================================"
    echo "GitHub Release Information for Home Assistant Custom Cards"
    echo "========================================================================"
    echo ""
fi

declare -a results=()

for card_name in "${!REPOS[@]}"; do
    repo="${REPOS[$card_name]}"

    if [[ "$JSON_OUTPUT" == false ]]; then
        echo -e "${BLUE}Checking: ${card_name}${NC}"
        echo "Repository: https://github.com/${repo}"
    fi

    info=$(get_release_info "$repo")

    if [[ $? -eq 0 ]]; then
        IFS='|' read -r tag date url name <<< "$info"

        if [[ "$JSON_OUTPUT" == false ]]; then
            echo -e "  ${GREEN}✓${NC} Latest Release: ${tag}"
            echo "  Release Date: ${date}"
            echo "  Release Name: ${name}"
            echo "  URL: ${url}"
            echo ""
        else
            results+=("{\"card\":\"$card_name\",\"repo\":\"$repo\",\"version\":\"$tag\",\"date\":\"$date\",\"url\":\"$url\",\"name\":\"$name\"}")
        fi
    else
        if [[ "$JSON_OUTPUT" == false ]]; then
            echo -e "  ${RED}✗${NC} Failed to fetch release: $info"
            echo ""
        else
            results+=("{\"card\":\"$card_name\",\"repo\":\"$repo\",\"error\":\"$info\"}")
        fi
    fi

    # Rate limiting: sleep briefly between requests
    sleep 0.5
done

if [[ "$JSON_OUTPUT" == true ]]; then
    echo "["
    printf '%s\n' "${results[@]}" | paste -sd ',' -
    echo "]"
else
    echo "========================================================================"
    echo "Summary:"
    echo "------------------------------------------------------------------------"
    echo "Total repositories checked: ${#REPOS[@]}"
    echo ""
    echo "Note: This script uses the GitHub API without authentication."
    echo "Rate limit: 60 requests per hour per IP address."
    echo "For more requests, authenticate with a GitHub token."
    echo "========================================================================"
fi

# Instructions for authentication (commented out)
# To use authentication, set GITHUB_TOKEN environment variable:
# export GITHUB_TOKEN="your_github_personal_access_token"
# Then modify curl command:
# curl -s -H "Accept: application/vnd.github.v3+json" \
#      -H "Authorization: token $GITHUB_TOKEN" \
#      "$url"
