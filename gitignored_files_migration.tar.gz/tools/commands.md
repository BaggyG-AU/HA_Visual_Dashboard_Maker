## To make the app
Run app: npm run start:wsl
Make app: npm run make -- --platform=win32 --arch=x64

## To clean up after merge
- git fetch origin
- git checkout main
- git pull --ff-only origin main

## Tests
- npn lint
- npm run test:unit
- npm run test:e2e --trace=retain-on-failure
- npm test --trace=retain-on-failure
- npm test --trace=retain-on-failure --last-failed