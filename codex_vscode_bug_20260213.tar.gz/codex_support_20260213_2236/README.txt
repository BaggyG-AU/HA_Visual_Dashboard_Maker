Capture time: Fri Feb 13 22:36:06 AEDT 2026
VS Code server logs folder: 20260213T222845
Current extension version: openai.chatgpt-0.5.74-linux-x64
Key errors: PendingMigrationError; state db missing rollout path; no rollout found
